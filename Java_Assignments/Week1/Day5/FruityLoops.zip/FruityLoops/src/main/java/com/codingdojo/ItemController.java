package com.codingdojo;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller	//use @Controller instead of @RestController
public class ItemController {

	@GetMapping("/")
	public String index(Model model) {		//this will make it render the .jsp file
		ArrayList<Item> items = new ArrayList<Item>();
		items.add(new Item("Kiwi", 1.5));
		items.add(new Item("Mango", 2.0));
		items.add(new Item("Goji Berries", 4.0));
		items.add(new Item("Guava", .75));
		
		model.addAttribute("cart", items);
		return "index";
	}
	 
	
	
}
