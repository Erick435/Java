package com.codingdojo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Greet {
	
	@RequestMapping("/")
	public String human(
			@RequestParam(value="name", required = false) String name, String lname, Integer times){
		
		String output = " ";
		for(int i = 0; i <= times; i++) {
			output += "Hello " + name + " " + lname+ " "; 
		}
		
		return output;
	}

}
