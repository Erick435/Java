
public class Practice {
    public static void main(String[] args){
        System.out.println("My name is Erick Ortega");
        System.out.println("I am 20 years old");
        System.out.println("My hometown is Queens, NY");
    }
}
