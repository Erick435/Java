
public class ZooKeeperTest {

	public static void main(String[] args) {
		
		Gorilla gorilla = new Gorilla();
		Bat darkBat = new Bat();

//==========GORILLA=====================
		
	//starting energy
	System.out.println("Starting gorilla energy: " + gorilla.displayEnergy());
		
	// throw 3 things
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.throwSomething();
	System.out.println("The gorilla now has: " +gorilla.displayEnergy());
		
	// eat 2 bananas
		gorilla.eatBananas();
		gorilla.eatBananas();
	System.out.println("The gorilla now has: " + gorilla.displayEnergy());
	
		
	// climb once
		gorilla.climb();
	System.out.println("The gorilla now has: " + gorilla.displayEnergy());
	
//=========BAT=====================
	
	System.out.println("\nDarkBat has entered the chat"
			+ "\nDarkBat has " + darkBat.displayEnergy());
//attack 3 towns
	
		darkBat.attackTown();
		darkBat.attackTown();
		darkBat.attackTown();
	System.out.println("After attacking, darkBat now has: " + darkBat.displayEnergy());
	
//eat 2 hoomans
		darkBat.eatHumans();
		darkBat.eatHumans();
	System.out.println("After eating hoomans, darkBat now has: " + darkBat.displayEnergy());

// fly 2 times	
		darkBat.fly();
		darkBat.fly();
	System.out.println("DarkBat flew 2 times, it now has: " + darkBat.displayEnergy());
	
	}
	
}
