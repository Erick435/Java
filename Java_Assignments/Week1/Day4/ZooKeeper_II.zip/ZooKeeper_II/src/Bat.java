
public class Bat extends Mammal{

//default energy = 300
	public Bat() {
		energyLevel = 300;
	}
	
//	methods: fly(), eatHumans(), attackTown()

	public void fly() {
		System.out.println("*Flap flap flap flap*");
		energyLevel -= 50;
	}
	
	public void eatHumans() {
		System.out.println("nom nom nom");
		energyLevel += 25;
	}
	
	public void attackTown() {
		System.out.println("*Screaming* *screeches* *buildings burning*");
		energyLevel -= 100;
	}	
}
