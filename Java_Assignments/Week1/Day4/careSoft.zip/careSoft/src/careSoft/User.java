package careSoft;

public class User {

	protected int pin;
	protected int id;
	
	//implement constructors
	public User() {
		//it's okay to have nothing here for the constructor
	}
	
	public User(int id) {
		this.id = id;
	}
	
	//GETTERS AND SETTERS
		
	public int getPin() {
		return pin;
	}
	
	public void setPin(int pin) {
		this.pin = pin;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
