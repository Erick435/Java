
public class ZooKeeperTest {

	public static void main(String[] args) {
		
		Gorilla gorilla = new Gorilla();
		
	//starting energy
	System.out.println("Starting gorilla energy: " + gorilla.displayEnergy());
		
	// throw 3 things
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.throwSomething();
	System.out.println("The gorilla now has: " +gorilla.displayEnergy());
		
	// eat 2 bananas
		gorilla.eatBananas();
		gorilla.eatBananas();
	System.out.println("The gorilla now has: " + gorilla.displayEnergy());
	
		
	// climb once
		gorilla.climb();
	System.out.println("The gorilla now has: " + gorilla.displayEnergy());
	
	
	}
	
}
