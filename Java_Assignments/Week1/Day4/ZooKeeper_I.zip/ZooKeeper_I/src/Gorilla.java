
public class Gorilla extends Mammal{

	public Gorilla() {
		super();
		//super is the same as doing "Mammal" 
// super() & Mammal, go to the extension of Mammal and use 
// their constructor
	}
	
	public void throwSomething() {
		System.out.println("The Gorilla has thrown something");
		energyLevel -= 5;
	}
	
	public void eatBananas() {
		System.out.println("Gorilla has eaten and is has regain +10 energy");
		energyLevel += 10;
	}
	
	public void climb() {
		System.out.println("Gorilla is climbing a tree : -10 energy");
		energyLevel -= 10;
	}
	
}
