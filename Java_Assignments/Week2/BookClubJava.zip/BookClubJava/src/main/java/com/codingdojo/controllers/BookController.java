package com.codingdojo.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.codingdojo.models.Book;
import com.codingdojo.service.BookService;

@Controller
@RequestMapping("/books")
public class BookController {

	@Autowired
	private BookService bookService;
	
	
	
	@GetMapping("")
	public String allBooks(Model model, HttpSession session) {
		if(session.getAttribute("user") == null) {
			return "redirect:/";
		}
		model.addAttribute("books", bookService.findAll());
		
		return "book_all";
	}
	
	@GetMapping("/{id}/edit")
	public String bookEdit(@PathVariable("id") Long bookId, Model model, HttpSession session) {
		if(session.getAttribute("user") == null) {
			return "redirect:/";
		}
		
		model.addAttribute("book", bookService.findById(bookId));
		return "book_edit";
		
	}
	
	@PostMapping("/{id}/edit")
	public String bookUpdate(@Valid @ModelAttribute("book") Book book, BindingResult result) {
		if(result.hasErrors()) {
			return "book_edit";
		}
		bookService.update(book);
		return "redirect:/books";
	}
	
	@GetMapping("/new")
	public String booknew(Model model, HttpSession session) {
		
		if(session.getAttribute("user") == null) {
			return "redirect:/";
		}
		
	//	send them blank book object
		model.addAttribute("book", new Book());
		return "book_new";
	}
	
	@GetMapping("/{id}")
	public String bookShow(@PathVariable("id") Long bookId, Model model, HttpSession session) {
		if (session.getAttribute("user") == null) {
			return "redirect:/";
		}
		model.addAttribute("book", bookService.findById(bookId));
		return "book_show";
	}
	
	@PostMapping("/new")			//IF NO HIDDEN INPUT IN .JSP ADD HttpSession session INTO PARAMETER
	public String bookCreate(@Valid @ModelAttribute("book") Book book, BindingResult result) {
		if(result.hasErrors()) {
			return "book_new";
		}
//		book.setUser((User) session.getAttribute("user"));			ONLY USE THIS IF YOU DON'T USE THE HIDDEN INPUT IN .JSP
		//This inserts it from mysql
		bookService.create(book);
		return "redirect:/books";
	}
	
	
}
