package com.codingdojo.service;


import javax.servlet.http.HttpSession;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.codingdojo.models.TempUser;
import com.codingdojo.models.User;
import com.codingdojo.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	
	public User login(TempUser tempUser, BindingResult result) {

		User db_user = userRepository.findByEmail(tempUser.getEmail());
		if(db_user == null) {
			result.rejectValue("email", "invalid_email", "Invalid Email");
			return null;
		}
		boolean ismatch=BCrypt.checkpw(tempUser.getPassword(), db_user.getPassword());
		if(!ismatch) {
			result.rejectValue("password", "invalid_password", "Password is invalid.");
			return null;
		}
			
			return db_user;
		
	}
	
	public User register(User user, BindingResult result) {
		
		if(userRepository.findByEmail(user.getEmail()) != null) {
			result.rejectValue("email", "email_invalid", "A user with this email already exists!");
			return null;
		}
		if(!user.getPassword().equals(user.getConfirm())) {
			result.rejectValue("password", "Password_invalid", "Password and Confirm Password do not match");
			result.rejectValue("confirm", "Password_invalid", "Password and Confirm Password do not match");
			return null;
		}
		
		String form_password=user.getPassword();
		String hash=BCrypt.hashpw(form_password, BCrypt.gensalt(8));
		user.setPassword(hash);
		userRepository.save(user);
		return user;
		
//		user.setPassword(BCrypt.hashpw(user.getPassword(), BCrypt.gensalt(8)));
//		userRepository.save(user);
//		return user;
	}
	
	public void logout(HttpSession session) {	
		if(session.getAttribute("user") != null) {			
			session.removeAttribute("user");
		}
	}
	

	
	
	
}
