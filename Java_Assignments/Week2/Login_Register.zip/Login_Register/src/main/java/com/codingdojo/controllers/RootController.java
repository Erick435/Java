package com.codingdojo.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;

import com.codingdojo.models.TempUser;
import com.codingdojo.models.User;
import com.codingdojo.service.UserService;

@Controller
//@RequestMapping("")
public class RootController
{
	
	@Autowired
	private UserService userService;
	

	@GetMapping(" ")
	public String login_register(Model model){
		model.addAttribute("userRegister", new User());
		model.addAttribute("userLogin", new TempUser());
		return "login_register";
	}
	
	@PostMapping("/register")
	public String register(@Valid @ModelAttribute("userRegister") User form_user, BindingResult result, Model model) {
		if(result.hasErrors()) {
			model.addAttribute("userLogin", new TempUser());
			return "login_register";
		}
		User db_user=userService.register(form_user, result);
		if(db_user == null) {
			model.addAttribute("userLogin", new TempUser());
			return "login_register";
		}
		return "redirect:/";
	}
	
	@PostMapping("/login")
	public String login(@Valid @ModelAttribute("userLogin") TempUser tempUser, BindingResult result, Model model, HttpSession session) {
		if(result.hasErrors()) {
			model.addAttribute("userRegister", new User());
			return "login_register";
		}
		User db_user = userService.login(tempUser, result);
		if(db_user == null) {
			model.addAttribute("userRegister", new User());
			return "login_register";
		}
		session.setAttribute("user", db_user);
		return "redirect:/dashboard";		// redirect either to dashboard or homepage that states it in
	}
	
	
	
	@GetMapping("/dashboard")
	public String dashboard(HttpSession session) {
		
		if(session.getAttribute("user") == null) {
			return "redirect:/";
		}
		return "dashboard";				//only change if you redirected it to another home page
	}
	
	
	
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		userService.logout(session);
		return "redirect:/";
	}
	
	
};