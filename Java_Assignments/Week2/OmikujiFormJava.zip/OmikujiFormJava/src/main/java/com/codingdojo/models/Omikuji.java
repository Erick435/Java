package com.codingdojo.models;

public class Omikuji {

	private Integer number;
	
	private String cityName;

	private String person;
	
	private String hobby;
	
	private String thing;
	
	private String somethingNice;
	
	public Omikuji(Integer number, String cityName, String person, String hobby, String thing, String somethingNice) {
		
		this.number = number;
		this.cityName = cityName;
		this.person = person;
		this.hobby = hobby;
		this.thing = thing;
		this.somethingNice = somethingNice;
		
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	public String getPerson() {
		return person;
	}
	
	public void setPerson(String person) {
		this.person = person;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}

	public String getThing() {
		return thing;
	}

	public void setThing(String thing) {
		this.thing = thing;
	}

	public String getSomethingNice() {
		return somethingNice;
	}

	public void setSomethingNice(String somethingNice) {
		this.somethingNice = somethingNice;
	}
	
	
}
