package com.codingdojo.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.codingdojo.models.Omikuji;


@Controller
public class RootController {
	
	
	@GetMapping("/Omikuji")
	public String home(HttpSession session) {
		if(session.getAttribute("omikujis") == null) {
			session.setAttribute("omikujis", new ArrayList<Omikuji>());
		}
		return "dashboard";
	}
	
	@PostMapping("/submit")
	public String render(
			@RequestParam("number") Integer number,
			@RequestParam("cityName")String cityName,
			@RequestParam("person") String person,
			@RequestParam("hobby") String hobby,
			@RequestParam("thing") String thing,
			@RequestParam("somethingNice") String somethingNice,
			HttpSession session) {
				
		
			ArrayList<Omikuji> omi = (ArrayList<Omikuji>) session.getAttribute("omikujis");
			omi.add(new Omikuji(number, cityName, person, hobby, thing, somethingNice));
			
				return "redirect:/Omikuji/show";
		
			}
	
	@GetMapping("/Omikuji/show")
	public String show(Model model, HttpSession session) {
		
		Omikuji omikuji = new Omikuji (
				(Integer) session.getAttribute("number"),
				(String) session.getAttribute("cityName"),
				(String) session.getAttribute("person"),
				(String) session.getAttribute("hobby"),
				(String) session.getAttribute("thing"),
				(String) session.getAttribute("somethingNice"));
		
		model.addAttribute("omikuji", omikuji);
		return "show";
	}
	
	@GetMapping("/reset")
	public String reset(HttpSession session) {
		session.invalidate();
		return "redirect:/Omikuji";
	}
	
	
}
