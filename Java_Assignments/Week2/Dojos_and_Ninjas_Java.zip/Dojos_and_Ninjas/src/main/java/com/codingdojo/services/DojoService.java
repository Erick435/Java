package com.codingdojo.services;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.models.Dojo;
import com.codingdojo.repositories.DojoRepository;

@Service
public class DojoService {

	@Autowired
	private DojoRepository dojoRepository;
	
	public void create(Dojo dojo) {
// 	insert into dojo(firstName, lastName, age) values(dojo.getfirst(), dojo.getLast(), dojo.getAge());
		dojoRepository.save(dojo);
	}
	
	public ArrayList<Dojo> findAll(){
//		select * from dojo;
		return (ArrayList<Dojo>) dojoRepository.findAll();
	}
	
	public Dojo findOne(Long id) {
//		select * from dojo where dojo.id = ?;
		Optional<Dojo> dojo = dojoRepository.findById(id);
		return dojo.isPresent()?dojo.get():null;
//		return dojoRepository.findById(id).orElse(null);
	}
	
	public void update(Dojo dojo) {
//		UPDATES 
		dojoRepository.save(dojo);
	}
	
	public void deleteById(Long id) {
//		delete from dojo where id = ?;
		dojoRepository.deleteById(id);
	}
	
}
