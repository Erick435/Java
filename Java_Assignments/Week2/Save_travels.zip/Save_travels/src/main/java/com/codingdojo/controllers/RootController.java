package com.codingdojo.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.codingdojo.models.Travel;
import com.codingdojo.services.TravelService;

@Controller
@RequestMapping("/expenses")
public class RootController {

	@Autowired
	private TravelService travelService;
	
	@GetMapping("")
	public String index(Model model) {
	//Creates a new travel class to add elements
		model.addAttribute("travel", new Travel());
		model.addAttribute("travels", travelService.findAll());
		return "index";
	}
	
	
	@PostMapping(" ")
	public String Create(@Valid @ModelAttribute("travel")Travel travel, BindingResult result) {
		if(result.hasErrors()) {
			return "index";
		}
		travelService.create(travel);
		return "redirect:/expenses";
	}
	
	@GetMapping("/{id}")
	public String show(@PathVariable("id")Long ExpenseId, Model model) {
		model.addAttribute("travel", travelService.findOne(ExpenseId));
		return "show";
	}
	
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id")Long ExpenseId, Model model) {
		model.addAttribute("travel", travelService.findOne(ExpenseId)); 
		return "edit";
	}
	
	@PostMapping("/edit/{id}")
	public String update(@Valid @ModelAttribute("travel")Travel travel, BindingResult result) {
		if(result.hasErrors()) {
			return "edit";
		}
		travelService.update(travel);
		return "redirect:/expenses";
	}
	
	@PostMapping("/delete/{id}")
	public String delete(@PathVariable("id")Long expenseId) {
		travelService.deleteOne(expenseId);
		return "redirect:/expenses";
	}
	
	
}
