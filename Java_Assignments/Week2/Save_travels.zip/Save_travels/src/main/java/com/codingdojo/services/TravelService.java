package com.codingdojo.services;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.models.Travel;
import com.codingdojo.repositories.TravelRepository;

@Service
public class TravelService {

	@Autowired
	private TravelRepository exRepo;
	
	public void create(Travel expense) {
		exRepo.save(expense);
	}
	
	public void update(Travel expense) {
		exRepo.save(expense);
	}
	
	public ArrayList<Travel> findAll(){
		return exRepo.findAll();
	}
	
	public Travel findOne(Long id) {
		Optional<Travel> expense = exRepo.findById(id);
		return expense.isPresent()?expense.get():null;
	}
	
	public void deleteOne(Long id) {
		exRepo.deleteById(id);
	}
	
}
