package com.codingdojo.repositories;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.codingdojo.models.Travel;

public interface TravelRepository extends CrudRepository<Travel, Long> {

	public ArrayList<Travel> findAll();
	
}
